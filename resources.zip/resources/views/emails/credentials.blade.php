@component('mail::message')
Nouveau message de  Ziouane Express
<br>
Email :  {{$data['email']}}.
<br>
Password :  {{$data['password']}}.
<br>
vous pouvez vous connecter sur :  {{$data['lien']}}.

Thanks,<br>
Ziouane Express
@endcomponent
