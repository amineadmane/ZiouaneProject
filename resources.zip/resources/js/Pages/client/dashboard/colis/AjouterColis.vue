<template>
<v-app app>
    <layout>
      <Drawer />
      <v-main>
        <v-container
        id="user-profile"
        fluid
        tag="section"
        class=""
      >
    <v-row justify="center">
      <v-col
        cols="12"
        md="12"
      >   
       
      <v-form action="" ref="form" v-model="valid" lazy-validation>
        
        <base-material-card
          color="primary"
          class="px-5 py-3 "
          width="40%"
        >
          <template v-slot:heading>
            <div class="display-2 font-weight-light text-center">
              Informations sur le client
            </div>
          </template>
          
          <v-row dense class="mt-4"  >
          <v-col cols="12" md="12">
            <v-text-field
              v-model="form.nomclient"
              :rules="[rules.required]"
              outlined
              label="Nom "
            >
            </v-text-field>
          </v-col>
          <v-col cols="12">
            <v-text-field
              v-model="form.telephone"
              outlined
              type="number"
              :rules="[rules.required]"
              label="Numéro de téléphone"
            ></v-text-field>
          </v-col>
          </v-row>
        </base-material-card>
        
        <base-material-card
          color="primary"
          class="px-5 py-3 mt-10"
          width="40%"
        >
          <template v-slot:heading>
            <div class="display-2 font-weight-light text-center">
              Informations sur la livraison
            </div>
          </template>
          <v-row dense class="mt-4">
                    <v-col cols="12">
                      <v-text-field
                        v-model="form.adresse"
                        outlined
                        :rules="[rules.required]"
                        label="Adresse"
                      ></v-text-field>
                    </v-col>
                    <v-col cols="12" md="4">
                      <v-select  
                        v-model="form.wilaya"
                        outlined
                        :items="wilayas"
                        item-text="wT"
                        item-value="to"
                        :rules="[rules.required]"
                        label="Wilaya"
                        @change="onChange"
                      >
                      </v-select>
                    </v-col>
                    <v-col cols="12" md="4">
                      <v-select
                        v-model="form.commune"
                        outlined
                        :items="communes"
                        item-text="nom"
                        item-value="id"
                        :rules="[rules.required]"
                        label="Commune"
                      ></v-select>
                    </v-col>
                    <v-col cols="12" md="4">
                      <v-text-field
                        outlined
                        label="Frais livraison"
                        disabled
                        v-model="form.fraisLivraison"
                      ></v-text-field>
                    </v-col>
                    <v-col cols="12">
                      <v-text-field
                        v-model="form.codePostal"
                        outlined
                        :rules="[rules.required]"
                        label="Code postal"
                      ></v-text-field>
                    </v-col>
          </v-row>
        </base-material-card>
        
        <base-material-card
          color="primary"
          class="px-5 py-3 mt-10"
          width="40%"
        >
          <template v-slot:heading>
            <div class="display-2 font-weight-light text-center">
              Informations sur la livraison
            </div>
          </template>
          <v-row dense class="mt-4">
                <v-col cols="12">
                  <v-text-field
                    v-model="form.produits"
                    outlined
                    :rules="[rules.required]"
                    label="Produit(s)"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" md="4">
                  <v-text-field
                    v-model="form.poids"
                    outlined
                    :rules="[rules.required]"
                    label="Poids (KG)"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" md="4">
                  <v-text-field
                    v-model="form.codecolis"
                    outlined
                    :rules="[rules.required]"
                    label="code commande"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" md="4">
                  <v-text-field
                    v-model="form.prix"
                    outlined
                    type="number"
                    :rules="[rules.required]"
                    label="Prix (DZD)"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" md="6">
                  <v-text-field
                    v-model="form.remarque"
                    outlined
                    label="Remarque"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" md="6">
                  <v-checkbox
                    v-model="form.livraison"
                    label="Livraison Gratuite"
                    color="red darken-3"
                  ></v-checkbox>
                </v-col>
          </v-row>
        </base-material-card>
      
      </v-form>
      <div class="d-flex justify-end">
       <v-btn
          color="primary"
          @click="validate"
        >
          Sauvegarder
      </v-btn>
       
      </div>   
    </v-col>

      
    </v-row>
  </v-container>
   
      </v-main>
    </layout>
    
    
    
</v-app>
</template>

<script>

import layout from '@/Shared/Default'
import axios from 'axios'
import Drawer from '../../Drawer'
export default {
    props: ['page','wilayas','communes'],
    components: {
        layout,
        Drawer
    },

   mounted(){
        
        this.wilayas.map(function(element){
          return element['wT']=element.wilaya_t['nom'];
        });
      },
    watch: {
      dialog (val) {
        val || this.close()
      },
      dialogDelete (val) {
        val || this.closeDelete()
      },
    },

    data () {
      return {
        fraisLivraison:0,
        form:{
          nomclient:'',
          codecolis:'',
          telephone:'',
          adresse:'',
          wilaya:'',
          prix:'',
          remarque:'',
          commune:'',
          codePostal:'',
          produits:'',
          poids:'',
          livraison:'',
          fraisLivraison:0,
        },
        communes:[],
        valid: true,
        lazy: false,
        e1:1,
        rules: {
        required: (value) => !!value ||  "Champ Obligatoire.",
        counter: (value) =>
          value.length >= 8 || "longueur minimum 8 caractères",
        email: (value) => {
          const pattern = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          return pattern.test(value) || "Invalid e-mail.";
        },
      },

      }
    },

    methods: {
      validate () {
        this.$refs.form.validate()
        if(this.$refs.form.validate()) return this.createColis();
      },
      
      createColis(){
        if(this.form.livraison==true) this.form.livraison=1;
        else this.form.livraison=0;
        this.$inertia.post(route('colis.store'),this.form).then(()=> {
          this.$toast.open({
            message: "Colis ajouté avec succés ",
            type: "success",
            duration: 9000,
            dismissible: true,
            position:"top-right"
          });
    });
      },
      onChange(){
        var _this = this ; 
        var element = this.wilayas.find(Element=>Element.id==this.form.wilaya);
        var x=this.wilayas.filter(function(element){
          return element.to == _this.form.wilaya;
        });
        
        this.form.fraisLivraison= x[0].prix;
        axios.get('/communes/'+this.form.wilaya).then((response) => {
            this.communes=response.data.communes
          })  
      },
      validate_form2() {
        this.$refs.form2.validate()
        if(this.$refs.form2.validate()) this.e1=3;
      },
      validate_form3() {
        this.$refs.form3.validate()
        if(this.$refs.form3.validate()) this.e1=3;
      },
    },

}
</script>








