<template>
  <v-app-bar
    id="app-bar"
    app
    color="transparent"
    flat
    height="75"
  >
    <v-btn
      class="mr-3"
      elevation="1"
      fab
      @click="goBack"
      small
      
    >
      
      <v-icon >
        mdi-arrow-left
      </v-icon>
      
    </v-btn>

    <v-toolbar-title
      class="hidden-sm-and-down font-weight-light"
      
    />

    

    <v-spacer />

    
    <div class="mx-3" />

    <v-btn
      class="ml-2"
      min-width="0"
      text
      @click="generateReport"
      
      
    >
      <v-icon>mdi-view-dashboard</v-icon>
      Imprimer
    </v-btn>

   
    <v-btn
      class="ml-2"
      min-width="0"
      text
      
    >
      <v-icon>mdi-account</v-icon>
    </v-btn>
  </v-app-bar>
</template>

<script>
  // Components
  import { VHover, VListItem } from 'vuetify/lib'

  // Utilities
  import { mapState, mapMutations } from 'vuex'

  export default {
    name: 'DashboardCoreAppBar',

    components: {
      AppBarItem: {
        render (h) {
          return h(VHover, {
            scopedSlots: {
              default: ({ hover }) => {
                return h(VListItem, {
                  attrs: this.$attrs,
                  class: {
                    'black--text': !hover,
                    'white--text secondary elevation-12': hover,
                  },
                  props: {
                    activeClass: '',
                    dark: hover,
                    link: true,
                    ...this.$attrs,
                  },
                }, this.$slots.default)
              },
            },
          })
        },
      },
    },

    props: {
      value: {
        type: Boolean,
        default: false,
      },
    },

    data: () => ({
      notifications: [
        'Mike John Responded to your email',
        'You have 5 new tasks',
        'You\'re now friends with Andrew',
        'Another Notification',
        'Another one',
      ],
    }),

    computed: {
      ...mapState(['drawer']),
    },

    methods: {
      ...mapMutations({
        setDrawer: 'SET_DRAWER',
      }),
      goBack(){
        this.$inertia.visit(route('client.colis'));
      },
      generateReport () {
      window.print();
    }
    },
  }
</script>
